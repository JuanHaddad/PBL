package com.example.PBL.util;

import org.springframework.stereotype.Component;

@Component
public class Calculadora {

    //CLASSE QUE EXECUTA TODOS OS CÁLCULOS
}
